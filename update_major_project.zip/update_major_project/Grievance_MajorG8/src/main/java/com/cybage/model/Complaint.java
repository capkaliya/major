package com.cybage.model;

import java.time.LocalDate;
import java.util.List;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
public class Complaint {
	@Id
	private  String compId;

	@Column(length = 1000)
	private  String description;
	@Column(length = 20)
	private  String status;
	@Column(length = 200)
	private  String file;
	@JsonIgnore
	@JsonFormat(pattern = "dd/MM/yyyy") 
	private  LocalDate date;
	@Column(length = 200)
	private  String remark;
	@ManyToOne
    @JoinColumn(name="citizenId", nullable=false,insertable = false, updatable = false)
	private  Citizen citizenId;
	@ManyToOne
    @JoinColumn(name="deptId", nullable=false,insertable = false, updatable = false)
	private  Department dept;
	 @OneToOne(fetch = FetchType.EAGER,
	            cascade =  CascadeType.ALL,
	            mappedBy = "compId")
	private Reminder reminder;	
	@OneToMany(mappedBy="compId")
	private List<Comment> comment;

	public Complaint() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Complaint(String compId, String description, String status, String file, LocalDate date, String remark,
			Citizen citizenId, Department dept, Reminder reminder, List<Comment> comment) {
		super();
		this.compId = compId;
	  this.description = description;
		this.status = status;
		this.file = file;
		this.date = date;
		this.remark = remark;
		this.citizenId = citizenId;
		this.dept = dept;
		this.reminder = reminder;
		this.comment = comment;
	}

	public String getCompId() {
		return compId;
	}

	public void setCompId(String compId) {
		this.compId = compId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Citizen getCitizenId() {
		return citizenId;
	}

	public void setCitizenId(Citizen citizenId) {
		this.citizenId = citizenId;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public Reminder getReminder() {
		return reminder;
	}

	public void setReminder(Reminder reminder) {
		this.reminder = reminder;
	}

	public List<Comment> getComment() {
		return comment;
	}

	public void setComment(List<Comment> comment) {
		this.comment = comment;
	}

	@Override
	public String toString() {
		return "Complaint [compId=" + compId + ", description=" + description + ", status=" + status + ", file=" + file
				+ ", date=" + date + ", remark=" + remark + ", citizenId=" + citizenId + ", dept=" + dept
				+ ", reminder=" + reminder + ", comment=" + comment + "]";
	}

}
