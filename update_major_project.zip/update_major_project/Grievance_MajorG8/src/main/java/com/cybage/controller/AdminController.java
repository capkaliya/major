//package com.cybage.controller;
//
//import java.util.List;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.cybage.model.Department;
//import com.cybage.service.AdminService;
//
//@RestController
//public class AdminController {
//	@Autowired
//	private AdminService service;
//	
//	@RequestMapping(name = "/departmentlist")
//	public List<Department> getDepartmentList(){
//		return service.getDepartmentList();
//	}
//
//}
