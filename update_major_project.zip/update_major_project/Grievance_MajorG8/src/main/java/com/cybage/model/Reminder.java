package com.cybage.model;

import java.time.LocalDate;

import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Reminder {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int rId;
	@JsonIgnore
	@JsonFormat(pattern = "dd/MM/yyyy") 
	private LocalDate date;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "compId", referencedColumnName = "compId")
	private Complaint compId;

	
	public Reminder() {
		// TODO Auto-generated constructor stub
	}
	public Reminder(int rId, LocalDate date, Complaint compId) {
		super();
		this.rId = rId;
		this.date = date;
		this.compId = compId;
	}

	public int getrId() {
		return rId;
	}

	public void setrId(int rId) {
		this.rId = rId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Complaint getCompId() {
		return compId;
	}

	public void setCompId(Complaint compId) {

		this.compId = compId;
	}

	@Override
	public String toString() {
		return "Reminder [rId=" + rId + ", date=" + date + ", compId=" + compId + "]";
	}

}
