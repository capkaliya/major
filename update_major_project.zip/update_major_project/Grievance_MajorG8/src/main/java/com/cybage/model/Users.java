package com.cybage.model;

import javax.persistence.*;

@Entity
@Table(name = "users")
public class Users {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userId;
	@Column(length = 50)
	private String username;
	@Column(length = 50)
	private String password;
	@Column(length = 20)
	private String role;
	@Column(length = 15)
	private String phone;
	@Column(length = 10)
	private String otp;
	private boolean status;
	@OneToOne(fetch = FetchType.EAGER,
	          cascade =  CascadeType.ALL,
	          mappedBy = "user")
	private DepartmentHead deptHead;
	@OneToOne(fetch = FetchType.EAGER,
	          cascade =  CascadeType.ALL,
	          mappedBy = "userId")
	private Citizen citizen;
	public Users() {
		
	}
	public Users(int userId, String username, String password, String role, String phone, String otp, boolean status,
			DepartmentHead deptHead, Citizen citizen) {
		super();
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.role = role;
		this.phone = phone;
		this.otp = otp;
		this.status = status;
		this.deptHead = deptHead;
		this.citizen = citizen;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public DepartmentHead getDeptHead() {
		return deptHead;
	}
	public void setDeptHead(DepartmentHead deptHead) {
		this.deptHead = deptHead;
	}
	public Citizen getCitizen() {
		return citizen;
	}
	public void setCitizen(Citizen citizen) {
		this.citizen = citizen;
	}
	@Override
	public String toString() {
		return "Users [userId=" + userId + ", username=" + username + ", password=" + password + ", role=" + role
				+ ", phone=" + phone + ", otp=" + otp + ", status=" + status + ", deptHead=" + deptHead + ", citizen="
				+ citizen + "]";
	}
		

}
