package com.cybage.model;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class Department {

	@Id
	private String deptId;
	@Column(length = 50)
	private String departmentName;
	 @OneToOne(fetch = FetchType.EAGER,
	            cascade =  CascadeType.ALL,
	            mappedBy = "dept")
	private DepartmentHead deptHead;
	@OneToMany(mappedBy="dept")
	private List<Complaint> complains;
	
	public Department() {
		super();	
	}

	public Department(String deptId, String departmentName, DepartmentHead deptHead, List<Complaint> complains) {
		super();
		this.deptId = deptId;
		this.departmentName = departmentName;
		this.deptHead = deptHead;
		this.complains = complains;
  }

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
  
	public DepartmentHead getDeptHead() {
		return deptHead;
	}

	public void setDeptHead(DepartmentHead deptHead) {
		this.deptHead = deptHead;
	}

	public List<Complaint> getComplains() {
		return complains;
	}

	public void setComplains(List<Complaint> complains) {
		this.complains = complains;
	}

	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", departmentName=" + departmentName + ", deptHead=" + deptHead
				+ ", complains=" + complains + "]";
	}

}	

