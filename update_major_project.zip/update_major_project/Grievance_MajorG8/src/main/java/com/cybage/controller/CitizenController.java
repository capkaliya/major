package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cybage.model.Complaint;
import com.cybage.repository.ComplaintRepository;
import com.cybage.service.CitizenService;

public class CitizenController {
	@Autowired
	CitizenService citizenservice;
	
	@Autowired
	ComplaintRepository compRepository;

	@PostMapping("/CompRegister")
	public ResponseEntity<?> registerFaculty(@RequestBody Complaint complaint) {
		System.out.println(complaint);
		citizenservice.save(complaint);
		return new ResponseEntity<Object>("OK", HttpStatus.OK);// new ResponseEntity<String>("User created success
																// full", HttpStatus.OK);
	}
	@GetMapping("details")
	public ResponseEntity<List<Complaint>> courseDetails() {

		return new ResponseEntity<List<Complaint>>(compRepository.findAll(), HttpStatus.OK);

	}
	
}
