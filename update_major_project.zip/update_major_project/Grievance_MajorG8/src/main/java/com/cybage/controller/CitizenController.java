package com.cybage.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cybage.model.Citizen;
import com.cybage.model.Complaint;
import com.cybage.repository.ComplaintRepository;
import com.cybage.service.CitizenService;
@RestController
public class CitizenController {
	@Autowired
	CitizenService citizenservice;

	@Autowired
	ComplaintRepository compRepository;

	private static String UPLOAD_DIR = "uploads";
	@PostMapping("/CompRegister")
	public ResponseEntity<?> registerComplaint(@RequestParam("file") MultipartFile file,@RequestParam("dept") String deptName,@RequestParam("desc") String description, HttpServletRequest request ) throws IOException, ServletException {
		
		Part filePart = request.getPart("file");
		String fileName =file.getOriginalFilename();
		System.out.println(fileName);
		String uploadPath = "E:\\update_major_project\\Grievance_MajorG8\\src\\main\\webapp\\" + UPLOAD_DIR  ;
		File dir = new File(uploadPath);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		uploadPath = uploadPath +File.separator + fileName;
		InputStream is = filePart.getInputStream();
		Files.copy(is, Paths.get(uploadPath), StandardCopyOption.REPLACE_EXISTING);
		//		System.out.println(complaint);
		//		complaint.getFile().ge
		//
		Complaint comp = new Complaint();
		comp.setDescription(description);
		comp.setFile(uploadPath);
		citizenservice.save(comp, deptName);
		return new ResponseEntity<Object>("OK", HttpStatus.OK);// new ResponseEntity<String>("User created success
		// full", HttpStatus.OK);
	}
	@GetMapping("details")
	public ResponseEntity<List<Complaint>> courseDetails() {

		return new ResponseEntity<List<Complaint>>(compRepository.findAll(), HttpStatus.OK);

	}



}
