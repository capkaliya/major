package com.cybage.model;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class DepartmentHead {

	@Id
	private String deptHeadId;
	@Column(length = 50)
	private String name;
	@Column(length = 50)
	private String email;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "dept", referencedColumnName = "deptId")
	private Department dept;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user", referencedColumnName = "userId")
	private Users user;
	public DepartmentHead() {
		super();
	}


	public DepartmentHead(String deptHeadId, String name, String email, Department dept, Users user) {
		super();
		this.deptHeadId = deptHeadId;
		this.name = name;
		this.email = email;
		this.dept = dept;
		this.user = user;
	}

	public String getDeptHeadId() {
		return deptHeadId;
	}

	public void setDeptHeadId(String deptHeadId) {
		this.deptHeadId = deptHeadId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "DepartmentHead [deptHeadId=" + deptHeadId + ", name=" + name + ", email=" + email + ", dept=" + dept
				+ ", user=" + user + "]";

	}

}
