package com.cybage.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Comment {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO )
	private  int commentId;
	@Column(length = 500)
	private  String comment;
	private  boolean isLiked;
	@ManyToOne
	@JoinColumn(name="compId", nullable=false,insertable = false, updatable = false)
	private  Complaint compId;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "citizen", referencedColumnName = "citizenId")
	private Citizen citizenId;
	public Comment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Comment(int commentId, String comment, boolean isLiked, Complaint compId, Citizen citizenId) {
		super();
		this.commentId = commentId;
		this.comment = comment;
		this.isLiked = isLiked;
		this.compId = compId;
		this.citizenId = citizenId;
	}

	public int getCommentId() {
		return commentId;
	}

	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public boolean isLiked() {
		return isLiked;
	}

	public void setLiked(boolean isLiked) {
		this.isLiked = isLiked;
	}

	public Complaint getCompId() {
		return compId;
	}

	public void setCompId(Complaint compId) {
		this.compId = compId;
	}

	public Citizen getCitizenId() {
		return citizenId;
	}

	public void setCitizenId(Citizen citizenId) {
		this.citizenId = citizenId;
	}

	@Override
	public String toString() {
		return "Comment [commentId=" + commentId + ", comment=" + comment + ", isLiked=" + isLiked + ", compId="
				+ compId + ", citizenId=" + citizenId + "]";
	}

	
}
