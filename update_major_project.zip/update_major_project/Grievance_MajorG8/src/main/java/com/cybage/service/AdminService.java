//package com.cybage.service;
//
//import java.util.List;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import com.cybage.model.Department;
//import com.cybage.repository.DepartmentRepository;
//
//@Service
//public class AdminService {
//	@Autowired
//	private DepartmentRepository dr;
//	public List<Department> getDepartmentList() {
//		return dr.findAll();
//	}
//
//
//}
