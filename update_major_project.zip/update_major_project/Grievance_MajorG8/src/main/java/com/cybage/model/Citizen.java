package com.cybage.model;

import java.util.List;
import javax.persistence.*;

@Entity
public class Citizen {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int citizenId;
	@Column(length = 50)
	private String name;
	@Column(length = 50)
	private String address;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user", referencedColumnName = "userId")
	private Users userId;
	@OneToMany(mappedBy="citizenId")
	private List<Complaint> complains;

	@OneToOne(fetch = FetchType.EAGER,
			cascade =  CascadeType.ALL,
			mappedBy = "citizenId")
	private Comment comment;

	public Citizen() {
		// TODO Auto-generated constructor stub
	}

	public Citizen(int citizenId, String name, String address, Users userId, List<Complaint> complains,
			Comment comment) {
		super();
		this.citizenId = citizenId;
		this.name = name;
		this.address = address;
		this.userId = userId;
		this.complains = complains;
		this.comment = comment;
	}
	

	public Citizen(int citizenId) {
		super();
		this.citizenId = citizenId;
	}

	public int getCitizenId() {
		return citizenId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Users getUserId() {
		return userId;
	}

	public void setUserId(Users userId) {
		this.userId = userId;
	}

	public List<Complaint> getComplains() {
		return complains;
	}

	public void setComplains(List<Complaint> complains) {
		this.complains = complains;
	}

	public Comment getComment() {
		return comment;
	}

	public void setComment(Comment comment) {
		this.comment = comment;
	}

	@Override
	public String toString() {
		return "Citizen [citizenId=" + citizenId + ", name=" + name + ", address=" + address + ", userId=" + userId
				+ ", complains=" + complains + ", comment=" + comment + "]";
	}


}
