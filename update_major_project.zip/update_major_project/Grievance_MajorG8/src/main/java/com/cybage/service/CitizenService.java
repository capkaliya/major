package com.cybage.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cybage.model.Complaint;
import com.cybage.repository.ComplaintRepository;

public class CitizenService {
@Autowired
ComplaintRepository compRepository;
	
	public void save(Complaint complaint) {
		
		compRepository.save(complaint);
		
		
	}

}
