package com.cybage.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.model.Citizen;
import com.cybage.model.Complaint;
import com.cybage.model.Department;
import com.cybage.repository.ComplaintRepository;

@Service
public class CitizenService {
	@Autowired
	ComplaintRepository compRepository;
	

	private String generateCompID(){
		return "C"+ Math.round(Math.random()*999999999);
	}
	
	

	public void save(Complaint complaint, String deptName) {
		Department dept = new Department(deptName);
		LocalDate today = LocalDate.now();
		Complaint comp = new Complaint(generateCompID(), complaint.getDescription(), "Active", complaint.getFile(), today, "Department Remark", new Citizen(1), new Department(1));
		compRepository.save(comp);
	}


}
