package com.cybage.model;

import org.springframework.web.multipart.MultipartFile;

public class ComplaintDto {
	private String deptId;
	private String description;
	private MultipartFile file;
	public ComplaintDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ComplaintDto(String deptId, String description, MultipartFile file) {
		super();
		this.deptId = deptId;
		this.description = description;
		this.file = file;
	}
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	
	

}
