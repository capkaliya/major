package com.cybage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrievanceMajorG8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
